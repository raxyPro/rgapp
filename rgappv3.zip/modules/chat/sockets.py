"""modules/chat/sockets.py

This project does not use websockets yet.

Note:
- This file previously duplicated routes.py by mistake.
- If/when you want realtime chat, add Flask-SocketIO (or similar) and implement
  join/send events here.
"""
