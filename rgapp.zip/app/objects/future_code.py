#this code is not used but is kept for reference
pf_data_full = """
{
    "name": " ",
    "role": " ",
    "email": " ",
    "organization": " ",
    "website": " ",
    "mobile": " ",
    "skills": [
        {
            "skill_title": " ",
            "skill_rating": " ",
            "skill_description": " ",
        },
        {
            "skill_title": " ",
            "skill_rating": " ",
            "skill_description": " ",
        },
        {
            "skill_title": " ",
            "skill_rating": " ",
            "skill_description": " ",
        }
    ],
    "services": [
        {
            "services_title": " ",
            "services_rating": " ",
            "skill_description": " ",
        },
        {
            "services_title": " ",
            "services_rating": " ",
            "skill_description": " ",
        },
        {
            "services_title": " ",
            "services_rating": " ",
            "skill_description": " ",
        },
        {
            "services_title": " ",
            "services_rating": " ",
            "skill_description": " ",
        },
        {
            "services_title": " ",
            "services_rating": " ",
            "skill_description": " ",
        },
        {
            "services_title": " ",
            "services_rating": " ",
            "skill_description": " ",
        }
    ]
}
"""