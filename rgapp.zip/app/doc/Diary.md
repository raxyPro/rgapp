10-Jul-25
can we focus the stock or something that people are interested

09-Jul-25
did not work much
08-Jul-25
worked on sector62 co-working

next make chat work good
show topic on left, message on right 
ability send message
ability to reply message
on load show all messages since all undread message (from all topic)
concept of read and unread message 
make the chat window looks themed and a book style with a styling text - there is chatgpt prompt 

profiles
next - ability to send profile by email
next - one page CV teamplate
next - two page CV template
Ability to upload image

improve cnts
show individual and services like diet and user will be able to ping message for diet consult

Super Idea
1. submit zip file to chat gpt and then let it generate all code
2. generate all prompt and let gpt do all of them togather

zip ideas
1. security 
2. use sepearate table for each user or db which they can host themselve and the plateform is just the frontend.
3. the chat , profiles and task and connect are all act in a separate div and also callable within layout. now ecah of them can be be a separate html like chat.html with only div and when they want to be called from dashboard only div page will be included and whenever they will be called indeoendent then there will be one frame page for all such pages. like frame.html which will have call to layout.html
4. generate an Admin page and that will be visibile only when admin flag is on for a user or even hard coded.
5. for profiles, add ability to send profiles and track

future
6. build a chess analysis engine
7. people can play chess togather
8. jigauanshu to do testing
9. ajith to do testing - computer training (setup a pc for computer training for pushpa and ajith) - eventually leading to computer trainign institute
10. automatic testing




07-Jul-25
with chat.html i am moving towards a fully DIV Component that works wtih javascript and is independent module can be called any where to load into a dashboard kind of page and serve full functionality